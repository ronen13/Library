# INNO-TECH | ספריית האינטרנט

אתר סטטי — ספריית כלים ואתרים טכנולוגיים, מותאם מובייל, מוכן לפריסה על Render.

## קבצים
```
index.html   ← מבנה הדף
style.css    ← עיצוב (dark theme, mobile-first)
app.js       ← לוגיקה, נתונים, חיפוש וסינון
render.yaml  ← קונפיגורציה לפריסה על Render
```

## פריסה על Render (Static Site)

### שיטה 1 — GitHub (מומלץ)
1. צור ריפו GitHub חדש ודחף את כל הקבצים
2. כנס ל-[render.com](https://render.com) → New → Static Site
3. חבר את הריפו
4. הגדר:
   - **Build command**: (השאר ריק)
   - **Publish directory**: `.`
5. לחץ **Create Static Site**
6. האתר יעלה תוך ~1 דקה בכתובת `https://inno-tech-library.onrender.com`

### שיטה 2 — גרור ושחרר
1. כנס ל-render.com → New → Static Site
2. בחר **"Deploy without connecting to Git"**
3. גרור את תיקיית הפרויקט כולה

## הוספת אתרים
פתח `app.js` וערוך את מערך `SITES`:

```js
{ 
  name: "שם האתר", 
  desc: "תיאור קצר בעברית", 
  emoji: "🔥", 
  cat: "ai",          // ai | dev | news | tools | learn | design | cloud
  url: "https://...", 
  tag: "תווית",
  tagClass: "tag-ai"  // tag-ai | tag-dev | tag-news | tag-tools | tag-learn | tag-design | tag-cloud
},
```

## קטגוריות קיימות
| מזהה | שם |
|------|----|
| ai | בינה מלאכותית |
| dev | פיתוח |
| news | חדשות טק |
| tools | כלים |
| learn | למידה |
| design | עיצוב |
| cloud | ענן ו-DevOps |
